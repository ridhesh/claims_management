export const environment = {
  production: true,
  AUTH_SERVICE_URL: 'http://localhost:8008/authorization',
  MEMBER_SERVICE_URL: 'http://localhost:8099/memberModule',
};
